clc
clear 
load cosine.mat;
load FSWeight.mat;
load Jaccard.mat;
load KSNS.mat;
load LNS.mat;
load Gaussian.mat;
ar = 0.1:0.1:0.9;
subplot(2,3,1)
plot(ar,cosine.RC(:,1),'-.oy',ar,FSWeight.RC(:,1),'--hm',ar,Jaccard.RC(:,1),'--+g',ar,Gaussian.RC(:,1),'-.dc',...
    ar,LNS.RC(:,1),'-or',ar,KSNS.RC(:,1),'-.*b','LineWidth',1.5);
set(gca,'xtick',[0.1:0.2:0.9],'xticklabel',[0.1:0.2:0.9])
set(gcf,'Position',[50,50,1200,600]);          
gs = legend('cosine','FSWeight','Jaccard','Gaussian','LNS','KSNS');
set(gs,'Position',[0.92,0.10,0.025,0.8],'FontSize',12);     
legend('boxon')
set (gca,'position',[0.06,0.59,0.22,0.36]);  
xlabel('\alpha','Fontsize',14)
ylabel('AUPR','Fontsize',12)
ylim([0.15 0.46])
title('(a)  LncRNAs interaction profile')



subplot(2,3,2)
FSWeight.RP = LNS.RP(1,1);
Jaccard.RP = KSNS.RP(1,1);
plot(ar,cosine.RP(:,1),'-.oy',ar(1),FSWeight.RP(1),'--hm',ar(1),Jaccard.RP(1),'--+g',ar,Gaussian.RP(:,1),'-.dc',...
    ar,LNS.RP(:,1),'-or',ar,KSNS.RP(:,1),'-.*b','LineWidth',1.5);
set(gca,'xtick',[0.1:0.2:0.9],'xticklabel',[0.1:0.2:0.9]) 
set (gca,'position',[0.355,0.59,0.22,0.36]);  
xlabel('\alpha','Fontsize',14)
ylabel('AUPR','Fontsize',12)
ylim([0.1 0.2])
title('(b)  lncRNAs expression profile')
% 
% 
% 
subplot(2,3,3)
FSWeight.RX = LNS.RX(1,1);
Jaccard.RX = KSNS.RX(1,1);
plot(ar,cosine.RX(:,1),'-.oy',ar(1),FSWeight.RX(1),'--hm',ar(1),Jaccard.RX(1),'--+g',ar,Gaussian.RX(:,1),'-.dc',...
    ar,LNS.RX(:,1),'-or',ar,KSNS.RX(:,1),'-.*b','LineWidth',1.5);
set(gca,'xtick',[0.1:0.2:0.9],'xticklabel',[0.1:0.2:0.9]) 
set (gca,'position',[0.65,0.59,0.22,0.36]);   
xlabel('\alpha','Fontsize',14)
ylabel('AUPR','Fontsize',12)
ylim([0.17 0.212])
title('(c)  lncRNAs sequence profile')
% 
subplot(2,3,5)
FSWeight.PX = LNS.PX(1,1);
Jaccard.PX = KSNS.PX(1,1);
plot(ar,cosine.PX(:,1),'-.oy',ar(1),FSWeight.PX(1),'--hm',ar(1),Jaccard.PX(1),'--+g',ar,Gaussian.PX(:,1),'-.dc',...
    ar,LNS.PX(:,1),'-or',ar,KSNS.PX(:,1),'-.*b','LineWidth',1.5);set(gca,'xtick',[0.1:0.2:0.9],'xticklabel',[0.1:0.2:0.9])  %������������뻭��߾�
set (gca,'position',[0.5,0.1,0.22,0.36]);  
xlabel('\alpha','Fontsize',14)
ylabel('AUPR','Fontsize',12)
ylim([0.05 0.36])
title('(e)  proteins CTD')


subplot(2,3,4)
plot(ar,cosine.PC(:,1),'-.oy',ar,FSWeight.PC(:,1),'--hm',ar,Jaccard.PC(:,1),'--+g',ar,Gaussian.PC(:,1),'-.dc',...
    ar,LNS.PC(:,1),'-or',ar,KSNS.PC(:,1),'-.*b','LineWidth',1.5);
set(gca,'xtick',[0.1:0.2:0.9],'xticklabel',[0.1:0.2:0.9])
set (gca,'position',[0.2,0.1,0.22,0.36]);   
xlabel('\alpha','Fontsize',14)
ylabel('AUPR','Fontsize',12)
ylim([0.08 0.46])
title('(d)  proteins interaction profile')